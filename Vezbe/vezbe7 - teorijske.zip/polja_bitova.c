#include<stdio.h>

struct{
    unsigned int polje1;
    unsigned int poje2;
} p1;

struct{
    unsigned int polje1 : 1;
    unsigned int poje2 : 1;
} p2;

int main() {
    printf("Zauzeto memorije za p1: %ld\n", sizeof(p1));
    printf("Zauzeto memorije za p2: %ld\n", sizeof(p2));
    return 0;
}