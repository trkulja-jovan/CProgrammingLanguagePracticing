#include<stdio.h>
#include<string.h>

union Data {
    int i;
    float f;
    char str[20];
};

int main() {
    union Data data;
    data.i = 2;
    data.f = 8.1;
    strcpy(data.str, "string");

    printf("data.i je %i\n", data.i);
    printf("data.f je %f\n", data.f);
    printf("data.str je %s\n", data.str);

    printf("---\n");

    data.i = 2;
    printf("data.i je %i\n", data.i);
    data.f = 8.1;
    printf("data.f je %f\n", data.f);
    strcpy(data.str, "string");
    printf("data.str je %s\n", data.str);
}