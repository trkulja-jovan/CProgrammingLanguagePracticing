#include<stdio.h>

struct Tacka {
    int x;
    int y;
};

typedef struct{
    int x; 
    int y;
    int z;
} Tacka3D;

int main() {
    struct Tacka t1 = {1, 2};
    struct Tacka tacke[3] = {
        {1, 2},
        {1, 3},
        {2, 3}
    };

    printf("t1 = {%i, %i}\n", t1.x, t1.y);
    printf("Niz tacaka:\n");
    for(int i = 0; i < 3; i++) {
        printf("{%i, %i}\n", tacke[i].x, tacke[i].y);
    }

    Tacka3D tacka = {1, 2, 3};
    printf("tacka = {%i, %i, %i}\n", tacka.x, tacka.y, tacka.z);

    return 0;
}