#include<stdio.h>
#include<stdlib.h>

int duzina_niza = 0;

void ucitaj_cene(float** matrica, int n) {
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            printf("Unesite cenu proizvoda na poziciji [%i][%i]: ", i, j);
            scanf("%f", &matrica[i][j]);
        }
    }
}

int veci_od(float b1, float b2) {
    return b1 > b2 ? 1 : 0;
}

int manji_od(float b1, float b2) {
    return b1 < b2 ? 1 : 0;
}

float** izdvoj(float** matrica, int n, float broj, int (*fun)(float, float)) {
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            if(fun(matrica[i][j], broj)){
                duzina_niza++;
            }
        }
    }

    float** ret_niz = malloc(duzina_niza * sizeof(float*));

    int k = 0;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            if(fun(matrica[i][j], broj)){
                ret_niz[k] = &matrica[i][j];
                k++;
            }
        }
    }

    return ret_niz;
}

void uvecaj(float* vrednost, float procenat) {
    (*vrednost)+=(*vrednost) * procenat / 100.0;
}

void umanji(float* vrednost, float procenat) {
    (*vrednost)-=(*vrednost) * procenat / 100.0;
}

void modifikuj_vrednosti(float** niz, float procenat, void (*fun)(float*, float)) {
    for(int i = 0; i < duzina_niza; i++) {
        fun(niz[i], procenat);
    }
}

int main() {
    int n;
    printf("Unesite n: ");
    scanf("%d", &n);
    float** matrica = malloc(n * sizeof(float*));
    for(int i = 0; i < n; i++) {
        matrica[i] = malloc(n * sizeof(float));
    }
    ucitaj_cene(matrica, n);
    int opcija;
    do{

        printf("Unesite 0 za uvecanje ili 1 za umanjenje: ");
        scanf("%d", &opcija);

    }while(opcija != 0 && opcija != 1);

    printf("Unesite cenu za uporedjivanje: ");
    float cena;
    scanf("%f", &cena);
    printf("Unesite procenat: ");
    float procenat;
    scanf("%f", &procenat);

    if(!opcija) {
        float** niz = izdvoj(matrica, n, cena, manji_od);
        modifikuj_vrednosti(niz, procenat, uvecaj);
    } else {
        float** niz = izdvoj(matrica, n, cena, veci_od);
        modifikuj_vrednosti(niz, procenat, umanji);
    }


    printf("Krajni rezultat:\n");
    for (int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            printf("%f\t", matrica[i][j]);
        }
        printf("\n");
    }
    
}